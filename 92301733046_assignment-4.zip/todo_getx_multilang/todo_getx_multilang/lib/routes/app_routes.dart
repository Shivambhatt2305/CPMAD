abstract class Routes {
  static const HOME = '/';
  static const ADD_EDIT = '/add-edit';
}
