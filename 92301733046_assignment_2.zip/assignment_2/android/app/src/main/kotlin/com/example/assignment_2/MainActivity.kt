package com.example.assignment_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
