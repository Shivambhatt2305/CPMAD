package com.example.practical_5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
