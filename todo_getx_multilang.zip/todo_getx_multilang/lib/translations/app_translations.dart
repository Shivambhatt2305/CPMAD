import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        // English
        'en_US': {
          'app_title': 'Todo',
          'add_todo': 'Add Todo',
          'edit_todo': 'Edit Todo',
          'hint_title': 'What do you need to do?',
          'save': 'Save',
          'cancel': 'Cancel',
          'empty': 'No tasks yet. Add one!',
          'theme': 'Theme',
          'language': 'Language',
          'clear_completed': 'Clear completed',
        },
        // German
        'de_DE': {
          'app_title': 'Aufgaben',
          'add_todo': 'Aufgabe hinzufügen',
          'edit_todo': 'Aufgabe bearbeiten',
          'hint_title': 'Was musst du erledigen?',
          'save': 'Speichern',
          'cancel': 'Abbrechen',
          'empty': 'Noch keine Aufgaben. Füge eine hinzu!',
          'theme': 'Thema',
          'language': 'Sprache',
          'clear_completed': 'Erledigte löschen',
        },
        // Gujarati (basic)
        'gu_IN': {
          'app_title': 'ટુડુ',
          'add_todo': 'કામ ઉમેરો',
          'edit_todo': 'કામ બદલો',
          'hint_title': 'શું કરવાનું છે?',
          'save': 'સેવ',
          'cancel': 'રદ કરો',
          'empty': 'હજુ કોઈ કામ નથી. એક ઉમેરો!',
          'theme': 'થીમ',
          'language': 'ભાષા',
          'clear_completed': 'પૂર્ણ થયેલ કાઢો',
        },
      };
}
