package com.example.practical_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
