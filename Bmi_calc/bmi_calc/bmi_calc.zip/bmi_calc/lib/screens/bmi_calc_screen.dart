import 'package:flutter/material.dart';

class BmiCalcScreen extends StatelessWidget {
  const BmiCalcScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}