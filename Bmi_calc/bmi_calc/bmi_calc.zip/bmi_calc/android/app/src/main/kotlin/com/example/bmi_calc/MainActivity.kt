package com.example.bmi_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
