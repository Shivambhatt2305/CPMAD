package com.example.gst_clc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
