package com.example.gold_price_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
