import 'package:flutter/material.dart';
import '../models/quote.dart';
import '../widgets/quote_card.dart';

class QuoteListScreen extends StatelessWidget {
  final List<Quote> history;

  const QuoteListScreen({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Quote History")),
      body: history.isEmpty
          ? const Center(child: Text("No quotes yet"))
          : ListView.builder(
              itemCount: history.length,
              itemBuilder: (context, index) {
                return QuoteCard(quote: history[index]);
              },
            ),
    );
  }
}
