import 'package:flutter/material.dart';
import '../models/quote.dart';
import '../services/api_service.dart';
import '../widgets/quote_card.dart';
import 'quote_list_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Quote? _currentQuote;
  final List<Quote> _history = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _fetchQuote();
  }

  Future<void> _fetchQuote() async {
    setState(() => _loading = true);
    try {
      final quote = await ApiService.fetchRandomQuote();
      setState(() {
        _currentQuote = quote;
        _history.add(quote);
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  void _openHistory() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuoteListScreen(history: _history),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Random Quotes"),
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            onPressed: _openHistory,
          ),
        ],
      ),
      body: Center(
        child: _loading
            ? const CircularProgressIndicator()
            : _currentQuote != null
                ? QuoteCard(quote: _currentQuote!)
                : const Text("No quote available"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchQuote,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
