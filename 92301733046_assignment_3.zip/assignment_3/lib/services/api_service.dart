import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/quote.dart';

class ApiService {
  static const String _url = 'https://dummyjson.com/quotes/random';

  static Future<Quote> fetchRandomQuote() async {
    final response = await http.get(Uri.parse(_url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return Quote(
        text: data['quote'],
        author: data['author'],
      );
    } else {
      throw Exception('Failed to load quote');
    }
  }
}
