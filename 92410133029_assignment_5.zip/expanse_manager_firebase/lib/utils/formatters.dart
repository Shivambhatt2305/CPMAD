import 'package:intl/intl.dart';

final dateFmt = DateFormat('dd MMM yyyy');
final currencyFmt = NumberFormat.currency(symbol: '₹');
