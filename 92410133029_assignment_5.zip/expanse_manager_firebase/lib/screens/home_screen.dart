import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/transaction_provider.dart';
import '../widgets/balance_card.dart';
import '../widgets/transaction_tile.dart';
import 'add_edit_transaction_screen.dart';
import '/footer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<TransactionProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Expense Manager'), centerTitle: true),
      body: prov.loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                BalanceCard(
                  balance: prov.balance,
                  income: prov.totalIncome,
                  expense: prov.totalExpense,
                ),
                Expanded(
                  child: prov.items.isEmpty
                      ? const Center(child: Text('No transactions yet'))
                      : ListView.builder(
                          itemCount: prov.items.length,
                          itemBuilder: (_, i) {
                            final tx = prov.items[i];
                            return TransactionTile(
                              tx: tx,
                              onDelete: () => prov.remove(tx.id),
                            );
                          },
                        ),
                ),
                const FooterText(), // Footer
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () =>
            Navigator.pushNamed(context, AddEditTransactionScreen.routeName),
        icon: const Icon(Icons.add),
        label: const Text('Add'),
        
        
      ),
      
    );
  }
}
