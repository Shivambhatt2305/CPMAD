import 'package:flutter/material.dart';

class BalanceCard extends StatelessWidget {
  final double balance;
  final double income;
  final double expense;

  const BalanceCard({
    super.key,
    required this.balance,
    required this.income,
    required this.expense,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Balance', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text('₹${balance.toStringAsFixed(2)}',
                style: Theme.of(context).textTheme.headlineMedium),
            const Divider(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _stat(context, 'Income', income),
                _stat(context, 'Expense', expense),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(BuildContext context, String label, double value) {
    return Column(
      children: [
        Text(label, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 4),
        Text('₹${value.toStringAsFixed(2)}',
            style: Theme.of(context).textTheme.titleLarge),
      ],
    );
  }
}
