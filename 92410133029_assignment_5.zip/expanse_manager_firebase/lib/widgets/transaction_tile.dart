import 'package:flutter/material.dart';
import '../models/transaction_model.dart';
import '../utils/formatters.dart';

class TransactionTile extends StatelessWidget {
  final TransactionModel tx;
  final VoidCallback? onDelete;

  const TransactionTile({super.key, required this.tx, this.onDelete});

  @override
  Widget build(BuildContext context) {
    final isIncome = tx.type == TxType.income;
    return Dismissible(
      key: ValueKey(tx.id),
      direction: DismissDirection.endToStart,
      background: Container(color: Colors.red),
      onDismissed: (_) => onDelete?.call(),
      child: ListTile(
        leading: CircleAvatar(
          child: Icon(isIncome ? Icons.arrow_downward : Icons.arrow_upward),
        ),
        title: Text(tx.category),
        subtitle: Text('${dateFmt.format(tx.date)}  •  ${tx.note}'),
        trailing: Text(
          (isIncome ? '+' : '-') + '₹${tx.amount.toStringAsFixed(2)}',
          style: TextStyle(
              color: isIncome ? Colors.green : Colors.red,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
