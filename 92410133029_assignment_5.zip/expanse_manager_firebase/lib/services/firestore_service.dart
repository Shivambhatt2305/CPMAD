import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/transaction_model.dart';

class FirestoreService {
  final _db = FirebaseFirestore.instance;
  CollectionReference get _col => _db.collection('transactions');

  Stream<List<TransactionModel>> streamTransactions() {
    return _col.orderBy('date', descending: true).snapshots().map(
        (snap) => snap.docs
            .map((d) => TransactionModel.fromMap(d.data() as Map<String, dynamic>, d.id))
            .toList());
  }

  Future<void> addTransaction(TransactionModel tx) async {
    await _col.add({
      ...tx.toMap(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateTransaction(TransactionModel tx) async {
    await _col.doc(tx.id).update(tx.toMap());
  }

  Future<void> deleteTransaction(String id) async {
    await _col.doc(id).delete();
  }
}
