import 'package:flutter/foundation.dart';
import '../services/firestore_service.dart';
import '../models/transaction_model.dart';

class TransactionProvider extends ChangeNotifier {
  final _service = FirestoreService();
  List<TransactionModel> _items = [];
  bool _loading = false;

  List<TransactionModel> get items => _items;
  bool get loading => _loading;

  double get totalIncome =>
      _items.where((t) => t.type == TxType.income).fold(0.0, (a, b) => a + b.amount);
  double get totalExpense =>
      _items.where((t) => t.type == TxType.expense).fold(0.0, (a, b) => a + b.amount);
  double get balance => totalIncome - totalExpense;

  void init() {
    _loading = true;
    notifyListeners();

    _service.streamTransactions().listen((data) {
      _items = data;
      _loading = false;
      notifyListeners();
    });
  }

  Future<void> add(TransactionModel tx) => _service.addTransaction(tx);
  Future<void> update(TransactionModel tx) => _service.updateTransaction(tx);
  Future<void> remove(String id) => _service.deleteTransaction(id);
}
