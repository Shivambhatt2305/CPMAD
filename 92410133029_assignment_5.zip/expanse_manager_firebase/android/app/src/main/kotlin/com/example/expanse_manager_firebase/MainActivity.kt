package com.example.expanse_manager_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
